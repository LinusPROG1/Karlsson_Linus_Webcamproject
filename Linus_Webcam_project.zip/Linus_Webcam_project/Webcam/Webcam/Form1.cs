﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebcamCapturer;
using Webcam;
using AForge.Video;
using AForge.Video.DirectShow;
using System.Data.SqlClient;

namespace Webcam
{
    public partial class Form1 : Form
    {
        public Random rnd = new Random();
        public Form1()
        {
            InitializeComponent();
        }
        FilterInfoCollection filterInfoCollection;
        VideoCaptureDevice videoCaptureDevice;
        Bitmap bitmap;
        private void FinalFrame_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            bitmap = (Bitmap)eventArgs.Frame.Clone();
            Camera.Image = bitmap;
            SavePicture();
        }
        private void SavePicture()
        {
            Bitmap current = (Bitmap)bitmap.Clone();
            string filepath = @"C:\Users\linus.karlsson16\Pictures\webcamlarm";
            string fileName = Path.Combine(filepath, DateTime.Now.ToString("yyyyMMdd_hh_mm_ss")+".png");
            current.Save(fileName);
            current.Dispose();
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            Camera.Visible = true;
            videoCaptureDevice = new VideoCaptureDevice(filterInfoCollection[ChooseCamera.SelectedIndex].MonikerString);
            videoCaptureDevice.NewFrame += FinalFrame_NewFrame;
            videoCaptureDevice.Start();
            label1.Visible = true;
            label2.Visible = true;
            RedArrow.Visible = false;
            ChooseCamera.Visible = true;
            button1.Enabled = false;

            string ConnectionString;
            SqlConnection con;
            ConnectionString = @"Data Source=CND8263QJW\PROG1DB;Initial Catalog=LinusdB;Integrated Security=True";
            con = new SqlConnection(ConnectionString);
            con.Open();
            SqlCommand command;
            SqlDataReader dataReader;
            string sql;
            sql = "SELECT Text FROM LinusTable";
            command = new SqlCommand(sql, con);
            dataReader = command.ExecuteReader();
            dataReader.Read();
            button1.Text = dataReader["Text"].ToString();
            con.Close();

            MessageBox.Show("haha dum dum");
        }
        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (videoCaptureDevice.IsRunning == true)
                videoCaptureDevice.Stop();
        }
        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            filterInfoCollection = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo Device in filterInfoCollection)
                ChooseCamera.Items.Add(Device.Name);
            ChooseCamera.SelectedIndex = 0;
            videoCaptureDevice = new VideoCaptureDevice();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            clock.Text = DateTime.Now.ToString("HH:mm:ss");
        }
        private void PictureBox2_Click(object sender, EventArgs e)
        {
        }

        private void PictureBox1_Click_1(object sender, EventArgs e)
        {

        }
    }
}